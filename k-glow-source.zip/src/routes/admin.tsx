import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-admin";
import { resolveImage } from "@/lib/product-images";
import { formatMAD } from "@/lib/currency";
import { LogOut, Plus, Trash2, Pencil, Upload, Package, ShoppingBag, Tag, X } from "lucide-react";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin · K·Glow" },
      { name: "description", content: "Manage the K·Glow catalogue, categories, and customer orders." },
      { name: "robots", content: "noindex" },
      { property: "og:title", content: "Admin · K·Glow" },
      { property: "og:description", content: "K·Glow admin dashboard." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AdminPage,
});

type Tab = "products" | "categories" | "orders";

type ProductRow = {
  id: string;
  name: string;
  brand: string;
  category: string;
  price: number | string;
  compare_at: number | string | null;
  stock: number;
  image_url: string | null;
  short: string;
  description: string;
  is_new: boolean;
  is_best: boolean;
  rating: number | string;
  reviews: number;
  tags: string[] | null;
  ingredients: string[] | null;
  benefits: string[] | null;
  how_to_use: string;
  sort_order: number;
};

type CategoryRow = { id: string; name: string; slug: string };

type OrderRow = {
  id: string;
  customer_email: string;
  customer_name: string | null;
  total: number | string;
  status: string;
  items: any;
  created_at: string;
};

function AdminPage() {
  const { user, isAdmin, loading } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>("products");

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  if (loading) {
    return <div className="min-h-screen grid place-items-center text-sm text-muted-foreground">Loading…</div>;
  }
  if (!user) return null;
  if (!isAdmin) {
    return (
      <div className="min-h-screen grid place-items-center px-6 text-center">
        <div>
          <h1 className="font-display text-3xl text-ink">Not an admin</h1>
          <p className="mt-3 text-sm text-muted-foreground">
            Your account ({user.email}) does not have admin access. Ask an existing admin to grant it.
          </p>
          <button
            className="mt-6 rounded-full bg-ink text-cream px-6 py-3 text-sm hover:bg-rose transition-colors"
            onClick={async () => {
              await supabase.auth.signOut();
              navigate({ to: "/auth" });
            }}
          >
            Sign out
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="hairline border-b bg-card sticky top-0 z-30">
        <div className="mx-auto max-w-7xl px-5 lg:px-10 h-16 flex items-center gap-6">
          <Link to="/" className="font-display text-2xl">K·<span className="text-rose">Glow</span> <span className="text-xs uppercase tracking-[0.25em] text-muted-foreground ml-2">Admin</span></Link>
          <nav className="hidden md:flex gap-1 ml-6">
            {(["products", "categories", "orders"] as Tab[]).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`px-4 py-2 rounded-full text-sm capitalize transition-colors ${
                  tab === t ? "bg-ink text-cream" : "hover:bg-blush-soft text-ink"
                }`}
              >
                {t === "products" ? <Package className="h-4 w-4 inline mr-1.5" /> : t === "categories" ? <Tag className="h-4 w-4 inline mr-1.5" /> : <ShoppingBag className="h-4 w-4 inline mr-1.5" />}
                {t}
              </button>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-3 text-sm">
            <span className="text-muted-foreground hidden sm:inline">{user.email}</span>
            <button
              onClick={async () => {
                await supabase.auth.signOut();
                navigate({ to: "/auth" });
              }}
              className="inline-flex items-center gap-1.5 rounded-full hairline bg-background px-4 py-2 hover:text-rose"
            >
              <LogOut className="h-4 w-4" /> Sign out
            </button>
          </div>
        </div>
        <div className="md:hidden flex gap-1 px-5 pb-3 overflow-x-auto">
          {(["products", "categories", "orders"] as Tab[]).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-4 py-2 rounded-full text-sm capitalize shrink-0 ${
                tab === t ? "bg-ink text-cream" : "bg-blush-soft text-ink"
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-5 lg:px-10 py-10">
        {tab === "products" && <ProductsPanel />}
        {tab === "categories" && <CategoriesPanel />}
        {tab === "orders" && <OrdersPanel />}
      </main>
    </div>
  );
}

/* ============ PRODUCTS ============ */

function ProductsPanel() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["admin", "products"],
    queryFn: async () => {
      const { data, error } = await supabase.from("products").select("*").order("sort_order").order("created_at");
      if (error) throw error;
      return data as ProductRow[];
    },
  });
  const [editing, setEditing] = useState<ProductRow | null>(null);
  const [creating, setCreating] = useState(false);

  async function remove(id: string) {
    if (!confirm("Delete this product? This cannot be undone.")) return;
    const { error } = await supabase.from("products").delete().eq("id", id);
    if (error) return alert(error.message);
    qc.invalidateQueries({ queryKey: ["admin", "products"] });
    qc.invalidateQueries({ queryKey: ["products"] });
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6 gap-4">
        <div>
          <h1 className="font-display text-3xl text-ink">Products</h1>
          <p className="text-sm text-muted-foreground mt-1">{data?.length ?? 0} items in the catalogue</p>
        </div>
        <button
          onClick={() => setCreating(true)}
          className="inline-flex items-center gap-2 rounded-full bg-ink text-cream px-5 py-2.5 text-sm hover:bg-rose transition-colors"
        >
          <Plus className="h-4 w-4" /> New product
        </button>
      </div>

      {isLoading ? (
        <div className="text-sm text-muted-foreground">Loading…</div>
      ) : (
        <div className="rounded-3xl bg-card hairline overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[720px]">
              <thead className="bg-blush-soft text-left text-xs uppercase tracking-[0.15em] text-ink/60">
                <tr>
                  <th className="p-4">Product</th>
                  <th className="p-4">Category</th>
                  <th className="p-4">Price</th>
                  <th className="p-4">Stock</th>
                  <th className="p-4"></th>
                </tr>
              </thead>
              <tbody>
                {data?.map((p) => (
                  <tr key={p.id} className="border-t hairline">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <img src={resolveImage(p.id, p.image_url)} alt="" className="h-12 w-12 rounded-xl object-cover bg-blush-soft" />
                        <div>
                          <div className="font-medium text-ink">{p.name}</div>
                          <div className="text-xs text-muted-foreground">{p.brand}</div>
                        </div>
                      </div>
                    </td>
                    <td className="p-4 text-ink/80">{p.category}</td>
                    <td className="p-4">{formatMAD(p.price)}</td>
                    <td className="p-4">
                      <span className={`${p.stock < 10 ? "text-rose" : "text-emerald-700"}`}>{p.stock}</span>
                    </td>
                    <td className="p-4 text-right">
                      <button onClick={() => setEditing(p)} className="p-2 hover:text-rose"><Pencil className="h-4 w-4" /></button>
                      <button onClick={() => remove(p.id)} className="p-2 hover:text-rose"><Trash2 className="h-4 w-4" /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {(editing || creating) && (
        <ProductForm
          product={editing}
          onClose={() => {
            setEditing(null);
            setCreating(false);
          }}
        />
      )}
    </div>
  );
}

function ProductForm({ product, onClose }: { product: ProductRow | null; onClose: () => void }) {
  const qc = useQueryClient();
  const isNew = !product;
  const [form, setForm] = useState<Partial<ProductRow>>(
    product ?? {
      id: "",
      name: "",
      brand: "",
      category: "Skincare",
      price: 0,
      compare_at: null,
      stock: 0,
      image_url: "",
      short: "",
      description: "",
      is_new: false,
      is_best: false,
      rating: 5,
      reviews: 0,
      tags: [],
      ingredients: [],
      benefits: [],
      how_to_use: "",
      sort_order: 100,
    },
  );
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { data: cats } = useQuery({
    queryKey: ["admin", "categories"],
    queryFn: async () => {
      const { data, error } = await supabase.from("categories").select("*").order("name");
      if (error) throw error;
      return data as CategoryRow[];
    },
  });

  function update<K extends keyof ProductRow>(k: K, v: ProductRow[K]) {
    setForm((f) => ({ ...f, [k]: v }));
  }
  function updateList(k: "tags" | "ingredients" | "benefits", v: string) {
    setForm((f) => ({ ...f, [k]: v.split(",").map((s) => s.trim()).filter(Boolean) }));
  }

  async function handleUpload(file: File) {
    setUploading(true);
    setError(null);
    try {
      const ext = file.name.split(".").pop() ?? "jpg";
      const path = `${(form.id || "product") + "-" + Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("product-images").upload(path, file, {
        cacheControl: "3600",
        upsert: true,
        contentType: file.type,
      });
      if (upErr) throw upErr;
      const { data: signed, error: sErr } = await supabase.storage
        .from("product-images")
        .createSignedUrl(path, 60 * 60 * 24 * 365 * 10);
      if (sErr) throw sErr;
      update("image_url", signed.signedUrl);
    } catch (e: any) {
      setError(e?.message ?? "Upload failed");
    } finally {
      setUploading(false);
    }
  }

  async function save() {
    setSaving(true);
    setError(null);
    try {
      const payload = {
        id: (form.id || "").trim(),
        name: form.name || "",
        brand: form.brand || "",
        category: form.category || "Skincare",
        price: Number(form.price) || 0,
        compare_at: form.compare_at ? Number(form.compare_at) : null,
        stock: Number(form.stock) || 0,
        image_url: form.image_url || null,
        short: form.short || "",
        description: form.description || "",
        is_new: !!form.is_new,
        is_best: !!form.is_best,
        rating: Number(form.rating) || 5,
        reviews: Number(form.reviews) || 0,
        tags: form.tags ?? [],
        ingredients: form.ingredients ?? [],
        benefits: form.benefits ?? [],
        how_to_use: form.how_to_use || "",
        sort_order: Number(form.sort_order) || 100,
      };
      if (!payload.id) throw new Error("ID (slug) is required, e.g. glow-serum");
      if (!payload.name) throw new Error("Name is required");

      if (isNew) {
        const { error } = await supabase.from("products").insert(payload);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("products").update(payload).eq("id", product!.id);
        if (error) throw error;
      }
      qc.invalidateQueries({ queryKey: ["admin", "products"] });
      qc.invalidateQueries({ queryKey: ["products"] });
      onClose();
    } catch (e: any) {
      setError(e?.message ?? "Save failed");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-ink/40 backdrop-blur-sm grid place-items-center p-4 overflow-y-auto">
      <div className="bg-background rounded-3xl w-full max-w-2xl my-8 max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 flex items-center justify-between p-6 border-b hairline bg-background z-10">
          <h2 className="font-display text-2xl text-ink">{isNew ? "New product" : "Edit product"}</h2>
          <button onClick={onClose} className="p-2 hover:text-rose"><X className="h-5 w-5" /></button>
        </div>
        <div className="p-6 space-y-5">
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="ID (slug)" required>
              <input
                value={form.id ?? ""}
                onChange={(e) => update("id", e.target.value)}
                disabled={!isNew}
                placeholder="glow-serum"
                className="input"
              />
            </Field>
            <Field label="Name" required>
              <input value={form.name ?? ""} onChange={(e) => update("name", e.target.value)} className="input" />
            </Field>
            <Field label="Brand">
              <input value={form.brand ?? ""} onChange={(e) => update("brand", e.target.value)} className="input" />
            </Field>
            <Field label="Category">
              <select value={form.category ?? ""} onChange={(e) => update("category", e.target.value)} className="input">
                {(cats ?? []).map((c) => <option key={c.id} value={c.name}>{c.name}</option>)}
                {(!cats || cats.length === 0) && <option>Skincare</option>}
              </select>
            </Field>
            <Field label="Price (MAD)"><input type="number" step="0.01" value={String(form.price ?? 0)} onChange={(e) => update("price", Number(e.target.value) as any)} className="input" /></Field>
            <Field label="Compare-at (MAD)"><input type="number" step="0.01" value={form.compare_at != null ? String(form.compare_at) : ""} onChange={(e) => update("compare_at", (e.target.value ? Number(e.target.value) : null) as any)} className="input" /></Field>
            <Field label="Stock"><input type="number" value={String(form.stock ?? 0)} onChange={(e) => update("stock", Number(e.target.value) as any)} className="input" /></Field>
            <Field label="Sort order"><input type="number" value={String(form.sort_order ?? 100)} onChange={(e) => update("sort_order", Number(e.target.value) as any)} className="input" /></Field>
            <Field label="Rating (0-5)"><input type="number" step="0.1" value={String(form.rating ?? 5)} onChange={(e) => update("rating", Number(e.target.value) as any)} className="input" /></Field>
            <Field label="Reviews"><input type="number" value={String(form.reviews ?? 0)} onChange={(e) => update("reviews", Number(e.target.value) as any)} className="input" /></Field>
          </div>

          <div className="flex gap-6">
            <label className="inline-flex items-center gap-2 text-sm"><input type="checkbox" checked={!!form.is_new} onChange={(e) => update("is_new", e.target.checked)} /> New</label>
            <label className="inline-flex items-center gap-2 text-sm"><input type="checkbox" checked={!!form.is_best} onChange={(e) => update("is_best", e.target.checked)} /> Best seller</label>
          </div>

          <Field label="Image">
            <div className="flex items-center gap-4">
              <div className="h-20 w-20 rounded-2xl overflow-hidden bg-blush-soft shrink-0">
                {form.image_url ? <img src={form.image_url} alt="" className="h-full w-full object-cover" /> : <div className="h-full w-full grid place-items-center text-xs text-muted-foreground">None</div>}
              </div>
              <label className="inline-flex items-center gap-2 rounded-full hairline bg-card px-4 py-2 text-sm cursor-pointer hover:text-rose">
                <Upload className="h-4 w-4" />
                {uploading ? "Uploading…" : "Upload"}
                <input type="file" accept="image/*" hidden onChange={(e) => e.target.files?.[0] && handleUpload(e.target.files[0])} />
              </label>
              {form.image_url && (
                <button onClick={() => update("image_url", "")} className="text-xs text-rose hover:underline">Remove</button>
              )}
            </div>
          </Field>

          <Field label="Short summary"><input value={form.short ?? ""} onChange={(e) => update("short", e.target.value)} className="input" /></Field>
          <Field label="Description"><textarea rows={4} value={form.description ?? ""} onChange={(e) => update("description", e.target.value)} className="input" /></Field>
          <Field label="How to use"><textarea rows={2} value={form.how_to_use ?? ""} onChange={(e) => update("how_to_use", e.target.value)} className="input" /></Field>
          <Field label="Tags (comma separated)"><input value={(form.tags ?? []).join(", ")} onChange={(e) => updateList("tags", e.target.value)} className="input" /></Field>
          <Field label="Ingredients (comma separated)"><input value={(form.ingredients ?? []).join(", ")} onChange={(e) => updateList("ingredients", e.target.value)} className="input" /></Field>
          <Field label="Benefits (comma separated)"><input value={(form.benefits ?? []).join(", ")} onChange={(e) => updateList("benefits", e.target.value)} className="input" /></Field>

          {error && <div className="text-sm text-rose">{error}</div>}
        </div>
        <div className="sticky bottom-0 flex justify-end gap-3 p-6 border-t hairline bg-background">
          <button onClick={onClose} className="rounded-full hairline bg-card px-5 py-2.5 text-sm">Cancel</button>
          <button onClick={save} disabled={saving} className="rounded-full bg-ink text-cream px-6 py-2.5 text-sm hover:bg-rose transition-colors disabled:opacity-60">
            {saving ? "Saving…" : "Save"}
          </button>
        </div>
      </div>
      <style>{`.input{width:100%;border-radius:9999px;background:hsl(var(--card));border:1px solid rgba(0,0,0,0.08);padding:0.65rem 1.15rem;font-size:0.875rem;outline:none}textarea.input{border-radius:1.25rem}.input:focus{box-shadow:0 0 0 2px hsl(var(--primary))}`}</style>
    </div>
  );
}

function Field({ label, children, required }: { label: string; children: React.ReactNode; required?: boolean }) {
  return (
    <label className="block">
      <span className="text-xs uppercase tracking-[0.15em] text-ink/60">
        {label}{required && <span className="text-rose"> *</span>}
      </span>
      <div className="mt-1.5">{children}</div>
    </label>
  );
}

/* ============ CATEGORIES ============ */

function CategoriesPanel() {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["admin", "categories"],
    queryFn: async () => {
      const { data, error } = await supabase.from("categories").select("*").order("name");
      if (error) throw error;
      return data as CategoryRow[];
    },
  });
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [error, setError] = useState<string | null>(null);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const { error } = await supabase.from("categories").insert({ name: name.trim(), slug: slug.trim() || name.toLowerCase().replace(/\s+/g, "-") });
    if (error) return setError(error.message);
    setName("");
    setSlug("");
    qc.invalidateQueries({ queryKey: ["admin", "categories"] });
  }
  async function remove(id: string) {
    if (!confirm("Delete this category?")) return;
    const { error } = await supabase.from("categories").delete().eq("id", id);
    if (error) return alert(error.message);
    qc.invalidateQueries({ queryKey: ["admin", "categories"] });
  }

  return (
    <div>
      <h1 className="font-display text-3xl text-ink mb-6">Categories</h1>
      <form onSubmit={add} className="rounded-3xl bg-card hairline p-6 mb-6 grid sm:grid-cols-[1fr_1fr_auto] gap-3">
        <input required value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" className="rounded-full hairline bg-background px-5 py-2.5 text-sm outline-none" />
        <input value={slug} onChange={(e) => setSlug(e.target.value)} placeholder="Slug (optional)" className="rounded-full hairline bg-background px-5 py-2.5 text-sm outline-none" />
        <button className="rounded-full bg-ink text-cream px-5 py-2.5 text-sm hover:bg-rose transition-colors">Add</button>
      </form>
      {error && <div className="text-sm text-rose mb-4">{error}</div>}
      <div className="rounded-3xl bg-card hairline divide-y">
        {(data ?? []).map((c) => (
          <div key={c.id} className="p-4 flex items-center justify-between">
            <div>
              <div className="font-medium text-ink">{c.name}</div>
              <div className="text-xs text-muted-foreground">{c.slug}</div>
            </div>
            <button onClick={() => remove(c.id)} className="p-2 hover:text-rose"><Trash2 className="h-4 w-4" /></button>
          </div>
        ))}
        {(!data || data.length === 0) && <div className="p-6 text-sm text-muted-foreground">No categories yet.</div>}
      </div>
    </div>
  );
}

/* ============ ORDERS ============ */

function OrdersPanel() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["admin", "orders"],
    queryFn: async () => {
      const { data, error } = await supabase.from("orders").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data as OrderRow[];
    },
  });

  async function setStatus(id: string, status: string) {
    const { error } = await supabase.from("orders").update({ status }).eq("id", id);
    if (error) return alert(error.message);
    qc.invalidateQueries({ queryKey: ["admin", "orders"] });
  }
  async function remove(id: string) {
    if (!confirm("Delete this order?")) return;
    const { error } = await supabase.from("orders").delete().eq("id", id);
    if (error) return alert(error.message);
    qc.invalidateQueries({ queryKey: ["admin", "orders"] });
  }

  return (
    <div>
      <h1 className="font-display text-3xl text-ink mb-6">Orders</h1>
      {isLoading ? (
        <div className="text-sm text-muted-foreground">Loading…</div>
      ) : !data || data.length === 0 ? (
        <div className="rounded-3xl bg-card hairline p-10 text-center text-muted-foreground">
          No orders yet. Once customers check out, they'll appear here.
        </div>
      ) : (
        <div className="rounded-3xl bg-card hairline overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[640px]">
              <thead className="bg-blush-soft text-left text-xs uppercase tracking-[0.15em] text-ink/60">
                <tr>
                  <th className="p-4">Date</th>
                  <th className="p-4">Customer</th>
                  <th className="p-4">Total</th>
                  <th className="p-4">Status</th>
                  <th className="p-4"></th>
                </tr>
              </thead>
              <tbody>
                {data.map((o) => (
                  <tr key={o.id} className="border-t hairline">
                    <td className="p-4 text-ink/80">{new Date(o.created_at).toLocaleString()}</td>
                    <td className="p-4">
                      <div className="text-ink">{o.customer_name || "—"}</div>
                      <div className="text-xs text-muted-foreground">{o.customer_email}</div>
                    </td>
                    <td className="p-4">{formatMAD(o.total)}</td>
                    <td className="p-4">
                      <select value={o.status} onChange={(e) => setStatus(o.id, e.target.value)} className="rounded-full hairline bg-background px-3 py-1.5 text-xs">
                        {["pending", "paid", "shipped", "delivered", "cancelled"].map((s) => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                    </td>
                    <td className="p-4 text-right">
                      <button onClick={() => remove(o.id)} className="p-2 hover:text-rose"><Trash2 className="h-4 w-4" /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
