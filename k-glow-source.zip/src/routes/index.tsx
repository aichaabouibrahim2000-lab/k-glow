import { createFileRoute, Link } from "@tanstack/react-router";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { ProductCard } from "@/components/site/ProductCard";
import { brands, useProducts, type Product } from "@/lib/products";
import hero from "@/assets/hero.jpg";
import promo from "@/assets/promo.jpg";
import { ArrowRight, Sparkles, Truck, ShieldCheck, Leaf, Star } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "K·Glow — Luxury Korean Beauty, Shipped from Seoul" },
      { name: "description", content: "Curated K-beauty rituals: serums, sheet masks, sunscreen and cushion foundations from the icons of Seoul. Free shipping over 600 DH." },
      { property: "og:title", content: "K·Glow — Luxury Korean Beauty, Shipped from Seoul" },
      { property: "og:description", content: "Curated K-beauty rituals: serums, sheet masks, sunscreen and cushion foundations from the icons of Seoul. Free shipping over 600 DH." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

function Home() {
  const { data: products = [] } = useProducts();
  const featured = products.slice(0, 4);
  const newArrivals = products.filter((p: Product) => p.isNew);
  const bestSellers = products.filter((p: Product) => p.isBest);

  return (
    <div className="bg-background text-foreground">
      <Nav />

      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="mx-auto max-w-7xl px-5 lg:px-10 pt-8 lg:pt-14">
          <div className="relative overflow-hidden rounded-[2rem] lg:rounded-[3rem] bg-blush">
            <img
              src={hero}
              alt="Luxury Korean skincare hero"
              width={1600}
              height={1200}
              className="absolute inset-0 h-full w-full object-cover"
            />
            <div className="relative grid lg:grid-cols-2 min-h-[560px] lg:min-h-[640px]">
              <div className="p-8 sm:p-12 lg:p-16 flex flex-col justify-end lg:justify-center">
                <div className="glass inline-flex w-fit items-center gap-2 rounded-full px-3.5 py-1.5 text-[11px] uppercase tracking-[0.22em] text-ink">
                  <Sparkles className="h-3 w-3" /> Spring Bloom Edit
                </div>
                <h1 className="mt-5 font-display text-5xl sm:text-6xl lg:text-7xl leading-[0.95] text-ink max-w-xl">
                  Skin like <span className="italic text-rose">petals</span>, ritual like poetry.
                </h1>
                <p className="mt-5 text-base sm:text-lg text-ink/70 max-w-md">
                  Curated Korean beauty for the modern ritual. Glass-skin essentials, sheet masks, and sunscreens shipped from Seoul.
                </p>
                <div className="mt-8 flex flex-wrap gap-3">
                  <Link
                    to="/shop"
                    className="inline-flex items-center gap-2 rounded-full bg-ink text-cream px-7 py-3.5 text-sm tracking-wide hover:bg-rose transition-colors"
                  >
                    Shop the edit <ArrowRight className="h-4 w-4" />
                  </Link>
                  <Link
                    to="/shop"
                    className="inline-flex items-center gap-2 rounded-full glass px-7 py-3.5 text-sm text-ink hover:text-rose transition-colors"
                  >
                    Explore brands
                  </Link>
                </div>
              </div>
              <div className="hidden lg:block" />
            </div>
          </div>
        </div>

        {/* Value bar */}
        <div className="mx-auto max-w-7xl px-5 lg:px-10 mt-8 grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { i: Truck, t: "Free shipping 600 DH+" },
            { i: ShieldCheck, t: "100% authentic" },
            { i: Leaf, t: "Cruelty-free" },
            { i: Sparkles, t: "Gift with 800 DH" },
          ].map(({ i: Icon, t }) => (
            <div key={t} className="hairline rounded-2xl px-4 py-3 flex items-center gap-3 bg-card">
              <Icon className="h-4 w-4 text-rose" />
              <span className="text-xs sm:text-sm text-ink/80">{t}</span>
            </div>
          ))}
        </div>
      </section>

      {/* PROMO / DISCOUNTS */}
      <section className="mx-auto max-w-7xl px-5 lg:px-10 mt-20 grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-blush to-blush-soft p-10 lg:p-14 min-h-[320px]">
          <div className="text-[11px] tracking-[0.25em] uppercase text-rose">Limited · This week</div>
          <h2 className="font-display text-4xl lg:text-6xl mt-3 text-ink max-w-md leading-[1]">
            Up to <span className="italic">30% off</span> the essentials.
          </h2>
          <p className="mt-4 text-ink/70 max-w-sm">Best-selling toners, serums and sunscreens on rare markdown. Ends Sunday.</p>
          <Link to="/shop" className="mt-8 inline-flex items-center gap-2 rounded-full bg-ink text-cream px-6 py-3 text-sm hover:bg-rose transition-colors">
            Shop the sale <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="relative overflow-hidden rounded-[2rem] bg-ink text-cream p-10 min-h-[320px] flex flex-col justify-between">
          <div>
            <div className="text-[11px] tracking-[0.25em] uppercase text-cream/60">Gift ritual</div>
            <h3 className="font-display text-3xl mt-3">Complimentary petal-print pouch with 800 DH.</h3>
          </div>
          <Link to="/shop" className="inline-flex items-center gap-2 text-sm text-rose group">
            Discover <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </div>
      </section>

      {/* FEATURED */}
      <Section
        eyebrow="Editor's picks"
        title="Featured this month"
        cta={{ label: "View all", to: "/shop" }}
      >
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-5 gap-y-10">
          {featured.map((p: Product) => <ProductCard key={p.id} product={p} />)}
        </div>
      </Section>

      {/* NEW ARRIVALS */}
      <Section eyebrow="Just landed" title="New arrivals" cta={{ label: "See all new", to: "/shop" }}>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-5 gap-y-10">
          {newArrivals.slice(0, 4).map((p: Product) => <ProductCard key={p.id} product={p} />)}
          {newArrivals.length < 4 && products.slice(0, 4 - newArrivals.length).map((p: Product) => (
            <ProductCard key={`f-${p.id}`} product={p} />
          ))}
        </div>
      </Section>

      {/* PROMO IMAGE */}
      <section className="mx-auto max-w-7xl px-5 lg:px-10 mt-24">
        <div className="relative overflow-hidden rounded-[2.5rem] grid lg:grid-cols-2 bg-cream">
          <img src={promo} alt="Model applying skincare" width={1400} height={1000} loading="lazy" className="h-full w-full object-cover min-h-[380px]" />
          <div className="p-10 lg:p-16 flex flex-col justify-center">
            <div className="text-[11px] tracking-[0.25em] uppercase text-rose">The K·Glow ritual</div>
            <h3 className="font-display text-4xl lg:text-5xl mt-3 text-ink leading-tight">
              Ten steps. One glass-skin finish.
            </h3>
            <p className="mt-5 text-ink/70 max-w-md">
              A guided routine from Seoul's most-loved dermatologists — refined into a modern morning and evening ritual.
            </p>
            <Link to="/shop" className="mt-8 inline-flex w-fit items-center gap-2 rounded-full bg-ink text-cream px-6 py-3 text-sm hover:bg-rose transition-colors">
              Discover the ritual <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* BEST SELLERS */}
      <Section eyebrow="Loved by thousands" title="Best sellers" cta={{ label: "Shop bestsellers", to: "/shop" }}>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-5 gap-y-10">
          {bestSellers.slice(0, 4).map((p: Product) => <ProductCard key={p.id} product={p} />)}
        </div>
      </Section>

      {/* BRANDS MARQUEE */}
      <section className="mt-24 border-y hairline bg-blush-soft py-10 overflow-hidden">
        <div className="text-center text-[11px] uppercase tracking-[0.3em] text-ink/60 mb-6">Trending Korean houses</div>
        <div className="flex overflow-hidden">
          <div className="flex shrink-0 gap-16 pr-16 animate-marquee whitespace-nowrap font-display text-3xl lg:text-4xl text-ink/70">
            {[...brands, ...brands].map((b, i) => (
              <span key={i} className="italic">{b}<span className="text-rose"> · </span></span>
            ))}
          </div>
        </div>
      </section>

      {/* REVIEWS */}
      <Section eyebrow="Reviews" title="Loved by the ritual-devoted">
        <div className="grid gap-6 md:grid-cols-3">
          {[
            { n: "Yuna K.", r: "The Radiance Serum changed my mornings. Actual glass skin in three weeks.", p: "Petalglow Serum" },
            { n: "Amara J.", r: "Zero white cast, invisible under makeup. My holy grail SPF.", p: "Kissed by Sun SPF" },
            { n: "Léa D.", r: "Packaging is a dream, the tint is a kiss. Buying every shade.", p: "Petal Melt Tint" },
          ].map((rv) => (
            <div key={rv.n} className="rounded-3xl bg-card hairline p-8">
              <div className="flex gap-0.5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-gold text-gold" />
                ))}
              </div>
              <p className="mt-5 font-display text-xl text-ink leading-snug">"{rv.r}"</p>
              <div className="mt-6 text-sm text-muted-foreground">— {rv.n} · <span className="text-rose">{rv.p}</span></div>
            </div>
          ))}
        </div>
      </Section>

      {/* NEWSLETTER */}
      <section className="mx-auto max-w-7xl px-5 lg:px-10 mt-24">
        <div className="rounded-[2.5rem] bg-blush p-10 lg:p-16 relative overflow-hidden">
          <div className="max-w-2xl">
            <div className="text-[11px] tracking-[0.25em] uppercase text-rose">Join the ritual</div>
            <h3 className="font-display text-4xl lg:text-5xl mt-3 text-ink leading-tight">
              15% off your first order.
            </h3>
            <p className="mt-4 text-ink/70">Early access to new arrivals, restocks, and Seoul-only launches.</p>
            <form className="mt-8 flex flex-col sm:flex-row gap-3 max-w-lg" onSubmit={(e) => e.preventDefault()}>
              <input
                type="email"
                placeholder="your@email.com"
                className="flex-1 rounded-full bg-white/80 backdrop-blur px-6 py-4 text-sm outline-none focus:ring-2 focus:ring-rose"
              />
              <button className="rounded-full bg-ink text-cream px-7 py-4 text-sm hover:bg-rose transition-colors">
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* INSTAGRAM GALLERY */}
      <Section eyebrow="@kglow.beauty" title="From our ritual">
        <div className="grid grid-cols-3 lg:grid-cols-6 gap-2 lg:gap-3">
          {products.map((p: Product) => (
            <a key={p.id} href="#" className="relative aspect-square overflow-hidden rounded-xl lg:rounded-2xl bg-blush-soft group">
              <img src={p.image} alt={p.name} loading="lazy" width={600} height={600} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" />
              <div className="absolute inset-0 bg-ink/0 group-hover:bg-ink/20 transition-colors" />
            </a>
          ))}
        </div>
      </Section>

      <Footer />
    </div>
  );
}

function Section({
  eyebrow,
  title,
  cta,
  children,
}: {
  eyebrow: string;
  title: string;
  cta?: { label: string; to: string };
  children: React.ReactNode;
}) {
  return (
    <section className="mx-auto max-w-7xl px-5 lg:px-10 mt-24">
      <div className="flex items-end justify-between gap-6 mb-10">
        <div>
          <div className="text-[11px] tracking-[0.25em] uppercase text-rose">{eyebrow}</div>
          <h2 className="font-display text-3xl lg:text-5xl text-ink mt-2">{title}</h2>
        </div>
        {cta && (
          <Link to={cta.to as "/shop"} className="hidden sm:inline-flex items-center gap-2 text-sm text-ink hover:text-rose">
            {cta.label} <ArrowRight className="h-4 w-4" />
          </Link>
        )}
      </div>
      {children}
    </section>
  );
}
