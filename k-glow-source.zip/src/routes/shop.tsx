import { createFileRoute } from "@tanstack/react-router";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { ProductCard } from "@/components/site/ProductCard";
import { useProducts, type Product } from "@/lib/products";
import { useMemo, useState } from "react";
import { SlidersHorizontal } from "lucide-react";

const CATEGORIES = ["All", "Skincare", "Makeup", "Sunscreen", "Hair Care"] as const;
const SORTS = ["Featured", "Price: Low to High", "Price: High to Low", "Top Rated", "Newest"] as const;

export const Route = createFileRoute("/shop")({
  head: () => ({
    meta: [
      { title: "Shop K-Beauty · K·Glow" },
      { name: "description", content: "Explore serums, sheet masks, sunscreens, cushion foundations and hair care from the icons of Seoul." },
      { property: "og:title", content: "Shop K-Beauty · K·Glow" },
      { property: "og:description", content: "Explore serums, sheet masks, sunscreens and hair care from Seoul." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Shop,
});

function Shop() {
  const { data: products = [], isLoading } = useProducts();
  const [cat, setCat] = useState<(typeof CATEGORIES)[number]>("All");
  const [sort, setSort] = useState<(typeof SORTS)[number]>("Featured");

  const list = useMemo(() => {
    const filtered = cat === "All" ? products : products.filter((p: Product) => p.category === cat);
    const sorted = [...filtered];
    switch (sort) {
      case "Price: Low to High": sorted.sort((a, b) => a.price - b.price); break;
      case "Price: High to Low": sorted.sort((a, b) => b.price - a.price); break;
      case "Top Rated": sorted.sort((a, b) => b.rating - a.rating); break;
      case "Newest": sorted.sort((a, b) => Number(!!b.isNew) - Number(!!a.isNew)); break;
    }
    return sorted;
  }, [cat, sort, products]);

  return (
    <div className="bg-background">
      <Nav />

      {/* Header */}
      <section className="mx-auto max-w-7xl px-5 lg:px-10 pt-10 lg:pt-16">
        <div className="text-[11px] tracking-[0.25em] uppercase text-rose">The shop</div>
        <h1 className="font-display text-5xl lg:text-7xl text-ink mt-3 leading-[0.95]">
          The whole <span className="italic">ritual</span>, curated.
        </h1>
        <p className="mt-5 max-w-xl text-ink/70">
          Every product tested, loved and hand-picked by our editors in Seoul. Serums, sheet masks, sunscreens and more.
        </p>
      </section>

      {/* Toolbar */}
      <section className="mx-auto max-w-7xl px-5 lg:px-10 mt-10">
        <div className="flex flex-col md:flex-row md:items-center gap-4 justify-between">
          <div className="flex gap-2 overflow-x-auto -mx-5 px-5 md:mx-0 md:px-0">
            {CATEGORIES.map((c) => (
              <button
                key={c}
                onClick={() => setCat(c)}
                className={`shrink-0 rounded-full px-5 py-2.5 text-sm border transition-all ${
                  cat === c
                    ? "bg-ink text-cream border-ink"
                    : "bg-card text-ink hairline hover:border-rose hover:text-rose"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-3">
            <SlidersHorizontal className="h-4 w-4 text-muted-foreground" />
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as (typeof SORTS)[number])}
              className="rounded-full bg-card hairline px-5 py-2.5 text-sm text-ink outline-none"
            >
              {SORTS.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
        </div>

        <div className="mt-3 text-xs text-muted-foreground">
          {isLoading ? "Loading…" : `${list.length} products`}
        </div>
      </section>

      {/* Grid */}
      <section className="mx-auto max-w-7xl px-5 lg:px-10 mt-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-5 gap-y-12">
          {list.map((p: Product) => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>

      <Footer />
    </div>
  );
}
