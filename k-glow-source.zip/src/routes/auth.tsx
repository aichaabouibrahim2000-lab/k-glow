import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in · K·Glow Admin" },
      { name: "description", content: "Sign in to manage the K·Glow catalogue and orders." },
      { name: "robots", content: "noindex" },
      { property: "og:title", content: "Sign in · K·Glow Admin" },
      { property: "og:description", content: "Admin sign in for K·Glow." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) navigate({ to: "/admin" });
    });
  }, [navigate]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setMessage(null);
    setLoading(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: `${window.location.origin}/admin` },
        });
        if (error) throw error;
        setMessage("Account created. If email confirmation is on, check your inbox — otherwise sign in below.");
        setMode("signin");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: "/admin" });
      }
    } catch (err: any) {
      setError(err?.message ?? "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="bg-background min-h-screen flex flex-col">
      <Nav />
      <main className="flex-1 grid place-items-center px-5 py-16">
        <div className="w-full max-w-md rounded-3xl bg-card hairline p-8 lg:p-10">
          <div className="text-[11px] tracking-[0.25em] uppercase text-rose">Admin access</div>
          <h1 className="font-display text-4xl text-ink mt-2">
            {mode === "signin" ? "Sign in" : "Create account"}
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            The first account created becomes the store admin automatically.
          </p>

          <form onSubmit={submit} className="mt-8 space-y-4">
            <label className="block">
              <span className="text-xs uppercase tracking-[0.18em] text-ink/70">Email</span>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1.5 w-full rounded-full bg-background hairline px-5 py-3 text-sm outline-none focus:ring-2 focus:ring-rose"
                placeholder="you@example.com"
              />
            </label>
            <label className="block">
              <span className="text-xs uppercase tracking-[0.18em] text-ink/70">Password</span>
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="mt-1.5 w-full rounded-full bg-background hairline px-5 py-3 text-sm outline-none focus:ring-2 focus:ring-rose"
                placeholder="••••••••"
              />
            </label>

            {error && <div className="text-sm text-rose">{error}</div>}
            {message && <div className="text-sm text-emerald-700">{message}</div>}

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-full bg-ink text-cream px-6 py-3.5 text-sm hover:bg-rose transition-colors disabled:opacity-60"
            >
              {loading ? "Please wait…" : mode === "signin" ? "Sign in" : "Create account"}
            </button>
          </form>

          <div className="mt-6 text-center text-sm text-muted-foreground">
            {mode === "signin" ? (
              <>
                No account yet?{" "}
                <button className="text-rose underline-offset-4 hover:underline" onClick={() => setMode("signup")}>
                  Create one
                </button>
              </>
            ) : (
              <>
                Already have one?{" "}
                <button className="text-rose underline-offset-4 hover:underline" onClick={() => setMode("signin")}>
                  Sign in
                </button>
              </>
            )}
          </div>

          <div className="mt-4 text-center text-xs text-muted-foreground">
            <Link to="/" className="hover:text-rose">← Back to store</Link>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
