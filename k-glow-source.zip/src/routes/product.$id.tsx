import { createFileRoute, Link } from "@tanstack/react-router";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { ProductCard } from "@/components/site/ProductCard";
import { useProduct, useProducts, type Product } from "@/lib/products";
import { formatMADShort } from "@/lib/currency";
import { useState } from "react";
import { Star, Heart, Share2, Minus, Plus, Truck, ShieldCheck, Leaf, ChevronDown } from "lucide-react";

export const Route = createFileRoute("/product/$id")({
  head: () => ({
    meta: [
      { title: "Product · K·Glow" },
      { name: "description", content: "Discover this Korean beauty essential from the K·Glow ritual." },
      { property: "og:title", content: "Product · K·Glow" },
      { property: "og:description", content: "Discover this Korean beauty essential from the K·Glow ritual." },
      { property: "og:type", content: "product" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProductPage,
});

function ProductPage() {
  const { id } = Route.useParams();
  const { data: product, isLoading } = useProduct(id);
  const { data: allProducts = [] } = useProducts();
  const [img, setImg] = useState<string | null>(null);
  const [qty, setQty] = useState(1);
  const [zoom, setZoom] = useState<{ x: number; y: number } | null>(null);

  if (isLoading) {
    return (
      <div className="bg-background min-h-screen"><Nav /><div className="mx-auto max-w-7xl px-5 lg:px-10 py-24 text-center text-muted-foreground">Loading product…</div><Footer /></div>
    );
  }
  if (!product) {
    return (
      <div className="bg-background min-h-screen"><Nav /><div className="mx-auto max-w-7xl px-5 lg:px-10 py-24 text-center">
        <h1 className="font-display text-4xl text-ink">Product not found</h1>
        <Link to="/shop" className="mt-6 inline-block text-rose hover:underline">Back to shop</Link>
      </div><Footer /></div>
    );
  }

  const currentImg = img ?? product.gallery[0];
  const related = allProducts.filter((p: Product) => p.id !== product.id && p.category === product.category).slice(0, 4);

  return (
    <div className="bg-background">
      <Nav />

      <div className="mx-auto max-w-7xl px-5 lg:px-10 pt-8">
        <nav className="text-xs text-muted-foreground flex gap-2">
          <Link to="/" className="hover:text-rose">Home</Link><span>/</span>
          <Link to="/shop" className="hover:text-rose">Shop</Link><span>/</span>
          <span className="text-ink">{product.name}</span>
        </nav>
      </div>

      <section className="mx-auto max-w-7xl px-5 lg:px-10 mt-6 grid lg:grid-cols-2 gap-10 lg:gap-16">
        {/* Gallery */}
        <div>
          <div
            className="relative aspect-square overflow-hidden rounded-[2rem] bg-blush-soft cursor-zoom-in"
            onMouseMove={(e) => {
              const r = e.currentTarget.getBoundingClientRect();
              setZoom({
                x: ((e.clientX - r.left) / r.width) * 100,
                y: ((e.clientY - r.top) / r.height) * 100,
              });
            }}
            onMouseLeave={() => setZoom(null)}
          >
            <img
              src={currentImg}
              alt={product.name}
              width={900}
              height={900}
              className="h-full w-full object-cover transition-transform duration-300"
              style={
                zoom
                  ? { transform: `scale(1.8)`, transformOrigin: `${zoom.x}% ${zoom.y}%` }
                  : undefined
              }
            />
          </div>
          <div className="mt-4 grid grid-cols-4 gap-3">
            {product.gallery.map((g: string, i: number) => (
              <button
                key={i}
                onClick={() => setImg(g)}
                className={`aspect-square overflow-hidden rounded-2xl bg-blush-soft border-2 transition-all ${
                  currentImg === g ? "border-rose" : "border-transparent hover:border-rose/40"
                }`}
              >
                <img src={g} alt="" className="h-full w-full object-cover" loading="lazy" />
              </button>
            ))}
          </div>
        </div>

        {/* Info */}
        <div className="lg:pt-4">
          <div className="text-[11px] tracking-[0.25em] uppercase text-rose">{product.brand}</div>
          <h1 className="font-display text-4xl lg:text-5xl text-ink mt-2 leading-tight">{product.name}</h1>
          <div className="mt-3 flex items-center gap-3 text-sm">
            <div className="flex items-center gap-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className={`h-4 w-4 ${i < Math.round(product.rating) ? "fill-gold text-gold" : "text-muted"}`} />
              ))}
              <span className="ml-1 text-ink font-medium">{product.rating}</span>
            </div>
            <span className="text-muted-foreground">({product.reviews.toLocaleString()} reviews)</span>
          </div>

          <p className="mt-5 text-ink/70 leading-relaxed">{product.short}</p>

          <div className="mt-6 flex items-baseline gap-3">
            <div className="font-display text-4xl text-ink">{formatMADShort(product.price)}</div>
            {product.compareAt && (
              <div className="text-lg text-muted-foreground line-through">{formatMADShort(product.compareAt)}</div>
            )}
            {product.compareAt && (
              <span className="bg-rose text-white rounded-full px-2.5 py-1 text-[10px] uppercase tracking-[0.15em]">
                −{Math.round(((product.compareAt - product.price) / product.compareAt) * 100)}%
              </span>
            )}
          </div>

          <div className="mt-2 text-xs text-emerald-700">
            {product.stock > 10 ? "In stock · ships in 24h" : `Only ${product.stock} left`}
          </div>

          <div className="mt-8 flex items-center gap-4">
            <div className="flex items-center gap-1 rounded-full hairline bg-card p-1">
              <button className="grid place-items-center h-10 w-10 rounded-full hover:bg-blush-soft" onClick={() => setQty((q) => Math.max(1, q - 1))}>
                <Minus className="h-4 w-4" />
              </button>
              <span className="w-8 text-center text-sm">{qty}</span>
              <button className="grid place-items-center h-10 w-10 rounded-full hover:bg-blush-soft" onClick={() => setQty((q) => q + 1)}>
                <Plus className="h-4 w-4" />
              </button>
            </div>
            <button className="flex-1 rounded-full bg-ink text-cream px-7 py-4 text-sm tracking-wide hover:bg-rose transition-colors">
              Add to bag
            </button>
          </div>

          <button className="mt-3 w-full rounded-full bg-rose text-white px-7 py-4 text-sm tracking-wide hover:opacity-90 transition-opacity">
            Buy it now
          </button>

          <div className="mt-4 flex gap-3">
            <button className="flex-1 rounded-full hairline bg-card px-5 py-3 text-sm text-ink hover:text-rose inline-flex items-center justify-center gap-2">
              <Heart className="h-4 w-4" /> Wishlist
            </button>
            <button className="flex-1 rounded-full hairline bg-card px-5 py-3 text-sm text-ink hover:text-rose inline-flex items-center justify-center gap-2">
              <Share2 className="h-4 w-4" /> Share
            </button>
          </div>

          <div className="mt-8 grid grid-cols-3 gap-2">
            {[{ i: Truck, t: "Free over 600 DH" }, { i: ShieldCheck, t: "Authentic" }, { i: Leaf, t: "Cruelty-free" }].map(({ i: Icon, t }) => (
              <div key={t} className="hairline rounded-2xl px-3 py-3 flex items-center gap-2 bg-card">
                <Icon className="h-4 w-4 text-rose" />
                <span className="text-xs text-ink/80">{t}</span>
              </div>
            ))}
          </div>

          {/* Accordions */}
          <div className="mt-10 divide-y hairline border-y">
            <Accordion title="Description" defaultOpen>
              <p className="text-ink/75 leading-relaxed">{product.description}</p>
            </Accordion>
            <Accordion title="Key ingredients">
              <ul className="space-y-2 text-ink/75">
                {product.ingredients.map((i: string) => <li key={i} className="flex gap-2"><span className="text-rose">·</span>{i}</li>)}
              </ul>
            </Accordion>
            <Accordion title="Benefits">
              <ul className="space-y-2 text-ink/75">
                {product.benefits.map((i: string) => <li key={i} className="flex gap-2"><span className="text-rose">·</span>{i}</li>)}
              </ul>
            </Accordion>
            <Accordion title="How to use">
              <p className="text-ink/75 leading-relaxed">{product.howToUse}</p>
            </Accordion>
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section className="mx-auto max-w-7xl px-5 lg:px-10 mt-24">
        <div className="text-[11px] tracking-[0.25em] uppercase text-rose">Reviews</div>
        <h2 className="font-display text-3xl lg:text-5xl text-ink mt-2">What the ritual says</h2>

        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {[
            { n: "Min-jae", r: 5, t: "Feels like water and finishes like silk. My new daily." },
            { n: "Chloé", r: 5, t: "Skin looks lit-from-within after two weeks. Obsessed." },
            { n: "Sana", r: 4, t: "Beautiful packaging, subtle scent, quick absorption." },
          ].map((rv, i) => (
            <div key={i} className="rounded-3xl bg-card hairline p-8">
              <div className="flex gap-0.5">
                {Array.from({ length: 5 }).map((_, j) => (
                  <Star key={j} className={`h-4 w-4 ${j < rv.r ? "fill-gold text-gold" : "text-muted"}`} />
                ))}
              </div>
              <p className="mt-5 font-display text-xl text-ink leading-snug">"{rv.t}"</p>
              <div className="mt-6 text-sm text-muted-foreground">— {rv.n} · verified buyer</div>
            </div>
          ))}
        </div>
      </section>

      {/* Related */}
      {related.length > 0 && (
        <section className="mx-auto max-w-7xl px-5 lg:px-10 mt-24">
          <div className="text-[11px] tracking-[0.25em] uppercase text-rose">The pairing</div>
          <h2 className="font-display text-3xl lg:text-5xl text-ink mt-2 mb-10">You may also love</h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-5 gap-y-10">
            {related.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>
      )}

      <Footer />
    </div>
  );
}

function Accordion({ title, children, defaultOpen = false }: { title: string; children: React.ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="py-5">
      <button onClick={() => setOpen((o) => !o)} className="w-full flex items-center justify-between text-left">
        <span className="font-display text-xl text-ink">{title}</span>
        <ChevronDown className={`h-4 w-4 text-ink transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && <div className="mt-4 text-sm">{children}</div>}
    </div>
  );
}
