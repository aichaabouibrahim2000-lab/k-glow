import { Link } from "@tanstack/react-router";
import { Search, Heart, ShoppingBag, User, Menu, X } from "lucide-react";
import { useState } from "react";

const NAV = [
  { label: "Shop", to: "/shop" as const },
  { label: "Skincare", to: "/shop" as const, search: { category: "Skincare" } },
  { label: "Makeup", to: "/shop" as const, search: { category: "Makeup" } },
  { label: "Sunscreen", to: "/shop" as const, search: { category: "Sunscreen" } },
  { label: "Hair Care", to: "/shop" as const, search: { category: "Hair Care" } },
  { label: "Brands", to: "/shop" as const },
  { label: "New", to: "/shop" as const, search: { filter: "new" } },
];

export function Nav() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50">
      <div className="bg-ink text-cream text-[11px] tracking-[0.2em] uppercase text-center py-2">
        Complimentary shipping over 600 DH · 15% off your first order
      </div>
      <div className="glass border-b border-black/5">
        <div className="mx-auto max-w-7xl px-5 lg:px-10 h-16 flex items-center gap-6">
          <button
            className="lg:hidden -ml-1 p-2"
            onClick={() => setOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>

          <Link to="/" className="font-display text-2xl tracking-tight shrink-0">
            K·<span className="text-rose">Glow</span>
          </Link>

          <nav className="hidden lg:flex items-center gap-7 text-[13px] font-medium text-foreground/80 mx-auto">
            {NAV.map((n) => (
              <Link
                key={n.label}
                to={n.to}
                className="hover:text-rose transition-colors"
              >
                {n.label}
              </Link>
            ))}
          </nav>

          <div className="ml-auto flex items-center gap-1">
            <button className="p-2 hover:text-rose" aria-label="Search"><Search className="h-[18px] w-[18px]" /></button>
            <Link to="/auth" className="p-2 hover:text-rose hidden sm:inline-flex" aria-label="Account"><User className="h-[18px] w-[18px]" /></Link>
            <button className="p-2 hover:text-rose hidden sm:inline-flex" aria-label="Wishlist"><Heart className="h-[18px] w-[18px]" /></button>
            <button className="p-2 hover:text-rose relative" aria-label="Cart">
              <ShoppingBag className="h-[18px] w-[18px]" />
              <span className="absolute -top-0.5 -right-0.5 bg-rose text-white text-[10px] rounded-full h-4 w-4 grid place-items-center">2</span>
            </button>
          </div>
        </div>
      </div>

      {open && (
        <div className="fixed inset-0 z-50 bg-background lg:hidden animate-fade-up">
          <div className="flex items-center justify-between px-5 h-16 border-b">
            <span className="font-display text-2xl">K·<span className="text-rose">Glow</span></span>
            <button onClick={() => setOpen(false)} aria-label="Close menu" className="p-2"><X className="h-5 w-5" /></button>
          </div>
          <nav className="px-6 py-8 flex flex-col gap-5 font-display text-3xl">
            {NAV.map((n) => (
              <Link key={n.label} to={n.to} onClick={() => setOpen(false)}>{n.label}</Link>
            ))}
            <Link to="/shop" onClick={() => setOpen(false)} className="text-rose">About</Link>
          </nav>
        </div>
      )}
    </header>
  );
}
