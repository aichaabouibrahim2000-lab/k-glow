import { Link } from "@tanstack/react-router";
import { Heart, Star } from "lucide-react";
import type { Product } from "@/lib/products";
import { formatMADShort } from "@/lib/currency";

export function ProductCard({ product }: { product: Product }) {
  const off =
    product.compareAt && product.compareAt > product.price
      ? Math.round(((product.compareAt - product.price) / product.compareAt) * 100)
      : null;

  return (
    <Link
      to="/product/$id"
      params={{ id: product.id }}
      className="group block"
    >
      <div className="relative aspect-square overflow-hidden rounded-3xl bg-blush-soft">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          width={900}
          height={900}
          className="h-full w-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-105"
        />
        <div className="absolute top-3 left-3 flex flex-col gap-1.5">
          {product.isNew && (
            <span className="glass rounded-full px-2.5 py-1 text-[10px] uppercase tracking-[0.18em] text-ink">New</span>
          )}
          {off && (
            <span className="bg-rose text-white rounded-full px-2.5 py-1 text-[10px] uppercase tracking-[0.18em]">
              −{off}%
            </span>
          )}
        </div>
        <button
          className="absolute top-3 right-3 glass grid place-items-center h-9 w-9 rounded-full text-ink opacity-0 group-hover:opacity-100 transition-opacity"
          aria-label="Add to wishlist"
          onClick={(e) => e.preventDefault()}
        >
          <Heart className="h-4 w-4" />
        </button>
      </div>

      <div className="pt-4 px-1">
        <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">{product.brand}</div>
        <div className="mt-1 flex items-start justify-between gap-3">
          <h3 className="font-display text-lg leading-tight text-ink group-hover:text-rose transition-colors">
            {product.name}
          </h3>
          <div className="text-right shrink-0">
            <div className="text-ink font-medium">{formatMADShort(product.price)}</div>
            {product.compareAt && (
              <div className="text-xs text-muted-foreground line-through">{formatMADShort(product.compareAt)}</div>
            )}
          </div>
        </div>
        <div className="mt-1.5 flex items-center gap-1 text-xs text-muted-foreground">
          <Star className="h-3 w-3 fill-gold text-gold" />
          <span className="text-ink">{product.rating}</span>
          <span>({product.reviews.toLocaleString()})</span>
        </div>
      </div>
    </Link>
  );
}
