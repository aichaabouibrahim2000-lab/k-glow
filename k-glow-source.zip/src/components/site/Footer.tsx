import { Instagram, Facebook, Youtube, Music2 } from "lucide-react";

export function Footer() {
  return (
    <footer className="mt-24 bg-ink text-cream/90">
      <div className="mx-auto max-w-7xl px-6 lg:px-10 py-16 grid gap-12 md:grid-cols-4">
        <div className="md:col-span-1">
          <div className="font-display text-3xl text-cream">K·<span className="text-rose">Glow</span></div>
          <p className="mt-4 text-sm text-cream/60 max-w-xs">
            Curated Korean beauty for the modern ritual. Shipped worldwide from Seoul.
          </p>
          <div className="mt-6 flex gap-3">
            {[Instagram, Music2, Youtube, Facebook].map((Icon, i) => (
              <a key={i} href="#" className="glass grid place-items-center h-9 w-9 rounded-full text-cream hover:text-rose">
                <Icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>

        {[
          { title: "Shop", links: ["Skincare", "Makeup", "Sunscreen", "Hair Care", "Brands"] },
          { title: "Company", links: ["About K·Glow", "Journal", "Sustainability", "Careers", "Press"] },
          { title: "Support", links: ["Help center", "Shipping", "Returns", "Contact", "Track order"] },
        ].map((col) => (
          <div key={col.title}>
            <div className="text-[11px] tracking-[0.25em] uppercase text-cream/50">{col.title}</div>
            <ul className="mt-4 space-y-3 text-sm">
              {col.links.map((l) => (
                <li key={l}><a href="#" className="hover:text-rose transition-colors">{l}</a></li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="border-t border-white/10">
        <div className="mx-auto max-w-7xl px-6 lg:px-10 py-6 flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-cream/50">
          <div>© {new Date().getFullYear()} K·Glow Beauty Co. Made in Seoul.</div>
          <div className="flex gap-5">
            <a href="#" className="hover:text-rose">Privacy</a>
            <a href="#" className="hover:text-rose">Terms</a>
            <a href="#" className="hover:text-rose">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
