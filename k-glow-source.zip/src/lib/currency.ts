export const CURRENCY_CODE = "MAD";
export const CURRENCY_SYMBOL = "DH";

/** Formats an amount in Moroccan Dirham, e.g. 249 -> "249,00 DH" */
export function formatMAD(amount: number | string | null | undefined): string {
  const n = Number(amount ?? 0);
  const safe = Number.isFinite(n) ? n : 0;
  return `${safe.toLocaleString("fr-MA", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })} ${CURRENCY_SYMBOL}`;
}

/** Compact form without decimals, e.g. 249 -> "249 DH" */
export function formatMADShort(amount: number | string | null | undefined): string {
  const n = Number(amount ?? 0);
  const safe = Number.isFinite(n) ? n : 0;
  const rounded = Math.round(safe * 100) / 100;
  return `${rounded.toLocaleString("fr-MA", { maximumFractionDigits: 2 })} ${CURRENCY_SYMBOL}`;
}
