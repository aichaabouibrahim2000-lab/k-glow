import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { resolveGallery, resolveImage } from "./product-images";

export type Product = {
  id: string;
  name: string;
  brand: string;
  category: string;
  price: number;
  compareAt?: number;
  rating: number;
  reviews: number;
  image: string;
  gallery: string[];
  tags: string[];
  stock: number;
  isNew?: boolean;
  isBest?: boolean;
  short: string;
  description: string;
  ingredients: string[];
  benefits: string[];
  howToUse: string;
  sortOrder?: number;
};

export const brands = [
  "Beauty of Joseon",
  "COSRX",
  "Laneige",
  "Innisfree",
  "Sulwhasoo",
  "Anua",
  "Torriden",
  "Round Lab",
];

type Row = {
  id: string;
  name: string;
  brand: string;
  category: string;
  price: number | string;
  compare_at: number | string | null;
  rating: number | string;
  reviews: number;
  image_url: string | null;
  gallery: string[] | null;
  tags: string[] | null;
  stock: number;
  is_new: boolean;
  is_best: boolean;
  short: string;
  description: string;
  ingredients: string[] | null;
  benefits: string[] | null;
  how_to_use: string;
  sort_order?: number | null;
};

function toProduct(r: Row): Product {
  return {
    id: r.id,
    name: r.name,
    brand: r.brand,
    category: r.category,
    price: Number(r.price),
    compareAt: r.compare_at != null ? Number(r.compare_at) : undefined,
    rating: Number(r.rating),
    reviews: r.reviews,
    image: resolveImage(r.id, r.image_url),
    gallery: resolveGallery(r.id, r.image_url, r.gallery ?? undefined),
    tags: r.tags ?? [],
    stock: r.stock,
    isNew: r.is_new || undefined,
    isBest: r.is_best || undefined,
    short: r.short,
    description: r.description,
    ingredients: r.ingredients ?? [],
    benefits: r.benefits ?? [],
    howToUse: r.how_to_use,
    sortOrder: r.sort_order ?? undefined,
  };
}

export async function fetchProducts(): Promise<Product[]> {
  const { data, error } = await supabase
    .from("products")
    .select("*")
    .order("sort_order", { ascending: true })
    .order("created_at", { ascending: true });
  if (error) throw error;
  return (data as unknown as Row[]).map(toProduct);
}

export async function fetchProduct(id: string): Promise<Product | null> {
  const { data, error } = await supabase.from("products").select("*").eq("id", id).maybeSingle();
  if (error) throw error;
  return data ? toProduct(data as unknown as Row) : null;
}

export function useProducts() {
  return useQuery({ queryKey: ["products"], queryFn: fetchProducts, staleTime: 30_000 });
}

export function useProduct(id: string) {
  return useQuery({
    queryKey: ["product", id],
    queryFn: () => fetchProduct(id),
    staleTime: 30_000,
  });
}
