import p1 from "@/assets/product-1.jpg";
import p2 from "@/assets/product-2.jpg";
import p3 from "@/assets/product-3.jpg";
import p4 from "@/assets/product-4.jpg";
import p5 from "@/assets/product-5.jpg";
import p6 from "@/assets/product-6.jpg";
import p7 from "@/assets/product-7.jpg";
import p8 from "@/assets/product-8.jpg";

export const PLACEHOLDER_IMAGE = p3;

// Fallback images for the seeded catalogue (looked up by product id).
export const FALLBACK_IMAGE: Record<string, string> = {
  "glow-serum": p1,
  "petal-mask": p2,
  "glass-essence": p3,
  "petal-tint": p4,
  "kissed-sun": p5,
  "silk-cushion": p6,
  "silk-hair": p7,
  "rice-toner": p8,
};

export const FALLBACK_GALLERY: Record<string, string[]> = {
  "glow-serum": [p1, p3, p8],
  "petal-mask": [p2, p1, p3],
  "glass-essence": [p3, p1, p8],
  "petal-tint": [p4, p6],
  "kissed-sun": [p5, p3],
  "silk-cushion": [p6, p4],
  "silk-hair": [p7, p3],
  "rice-toner": [p8, p3, p1],
};

export function resolveImage(id: string, url?: string | null): string {
  if (url && url.trim()) return url;
  return FALLBACK_IMAGE[id] ?? PLACEHOLDER_IMAGE;
}

export function resolveGallery(id: string, url?: string | null, gallery?: string[] | null): string[] {
  if (gallery && gallery.length > 0) return gallery;
  if (url && url.trim()) return [url];
  return FALLBACK_GALLERY[id] ?? [FALLBACK_IMAGE[id] ?? PLACEHOLDER_IMAGE];
}
