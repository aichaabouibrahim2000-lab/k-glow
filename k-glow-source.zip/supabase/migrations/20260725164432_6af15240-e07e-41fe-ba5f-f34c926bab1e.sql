
-- Roles
CREATE TYPE public.app_role AS ENUM ('admin', 'user');

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own roles readable" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;

-- Bootstrap: first user becomes admin, subsequent users are 'user'
CREATE OR REPLACE FUNCTION public.handle_new_user_role()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'admin') THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin');
  ELSE
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'user');
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user_role();

-- Categories
CREATE TABLE public.categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  slug text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.categories TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.categories TO authenticated;
GRANT ALL ON public.categories TO service_role;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "categories public read" ON public.categories FOR SELECT USING (true);
CREATE POLICY "categories admin write" ON public.categories FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- Products
CREATE TABLE public.products (
  id text PRIMARY KEY,
  name text NOT NULL,
  brand text NOT NULL DEFAULT '',
  category text NOT NULL,
  price numeric(10,2) NOT NULL DEFAULT 0,
  compare_at numeric(10,2),
  rating numeric(3,2) NOT NULL DEFAULT 5.0,
  reviews integer NOT NULL DEFAULT 0,
  image_url text,
  gallery text[] NOT NULL DEFAULT '{}',
  tags text[] NOT NULL DEFAULT '{}',
  stock integer NOT NULL DEFAULT 0,
  is_new boolean NOT NULL DEFAULT false,
  is_best boolean NOT NULL DEFAULT false,
  short text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  ingredients text[] NOT NULL DEFAULT '{}',
  benefits text[] NOT NULL DEFAULT '{}',
  how_to_use text NOT NULL DEFAULT '',
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.products TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.products TO authenticated;
GRANT ALL ON public.products TO service_role;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "products public read" ON public.products FOR SELECT USING (true);
CREATE POLICY "products admin write" ON public.products FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;
CREATE TRIGGER products_updated_at BEFORE UPDATE ON public.products
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Orders
CREATE TABLE public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_email text NOT NULL,
  customer_name text,
  total numeric(10,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending',
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT INSERT ON public.orders TO anon, authenticated;
GRANT SELECT, UPDATE, DELETE ON public.orders TO authenticated;
GRANT ALL ON public.orders TO service_role;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "orders public insert" ON public.orders FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "orders admin read" ON public.orders FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(),'admin'));
CREATE POLICY "orders admin update" ON public.orders FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "orders admin delete" ON public.orders FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(),'admin'));

-- Seed categories
INSERT INTO public.categories (name, slug) VALUES
  ('Skincare','skincare'),
  ('Makeup','makeup'),
  ('Hair Care','hair-care'),
  ('Sunscreen','sunscreen');

-- Seed 8 products (matching current catalog; images resolved via frontend fallback map by id)
INSERT INTO public.products (id,name,brand,category,price,compare_at,rating,reviews,tags,stock,is_new,is_best,short,description,ingredients,benefits,how_to_use,sort_order) VALUES
('glow-serum','Petalglow Radiance Serum','Sulwhasoo','Skincare',48,62,4.9,1284,ARRAY['Hydrating','Brightening'],42,false,true,
 'Weightless niacinamide serum for a lit-from-within glow.',
 'A featherlight serum infused with 5% niacinamide, rice bran, and mugwort. Diminishes dullness and refines pores while replenishing the moisture barrier for that signature glass-skin finish.',
 ARRAY['Niacinamide 5%','Rice Bran Extract','Mugwort','Panthenol','Hyaluronic Acid'],
 ARRAY['Evens skin tone','Refines texture','Deep hydration','Non-comedogenic'],
 'After toning, dispense 3–4 drops into palms and press gently into face and neck. Use morning and night before moisturiser.',1),
('petal-mask','Cherry Blossom Sheeting Mask','Innisfree','Skincare',6,NULL,4.8,812,ARRAY['Soothing'],120,true,false,
 'Cocoon your skin in a bloom of hydration.',
 'A biocellulose sheet drenched in cherry blossom essence and hyaluronic acid to plump, calm, and pearlise the skin in 15 minutes.',
 ARRAY['Cherry Blossom Extract','Hyaluronic Acid','Centella Asiatica','Squalane'],
 ARRAY['Instant plumping','Calms redness','Boosts radiance'],
 'Apply to cleansed skin for 15–20 minutes. Pat remaining essence in. Discard sheet.',2),
('glass-essence','Glass Skin Essence','Laneige','Skincare',38,NULL,4.9,2103,ARRAY['Hydrating','Barrier'],65,false,true,
 'The essence behind the K-beauty glass-skin finish.',
 'A milky essence formulated with fermented rice water and probiotics to fortify the barrier and deliver a translucent, dewy finish.',
 ARRAY['Fermented Rice Water','Probiotics','Ceramides','Peptides'],
 ARRAY['Barrier repair','Glassy finish','Long-lasting hydration'],
 'Warm 2 pumps between palms and press into damp skin after toner.',3),
('petal-tint','Petal Melt Lip Tint','Laneige','Makeup',22,28,4.7,934,ARRAY['Buildable','Vegan'],88,true,false,
 'A watery flush that melts into lips.',
 'A jelly-textured lip tint that stains lips with a soft-focus petal wash. Infused with shea and squalane for cushiony wear.',
 ARRAY['Shea Butter','Squalane','Vitamin E','Rose Extract'],
 ARRAY['12h wear','Non-drying','Buildable coverage'],
 'Glide across lips for a sheer wash, or layer for a saturated stain.',4),
('kissed-sun','Kissed by Sun SPF 50+ Fluid','Round Lab','Sunscreen',24,NULL,4.9,1567,ARRAY['SPF 50+','PA++++'],210,false,true,
 'Invisible daily UV shield with a satin finish.',
 'A featherweight chemical-mineral hybrid SPF 50+ PA++++ that layers seamlessly under makeup with zero white cast.',
 ARRAY['Zinc Oxide','Centella Asiatica','Green Tea','Niacinamide'],
 ARRAY['Broad spectrum','No white cast','Reef-safe'],
 'Apply generously as the final step of your morning routine. Reapply every 2 hours.',5),
('silk-cushion','Silk Veil Cushion Foundation','Sulwhasoo','Makeup',54,NULL,4.8,621,ARRAY['Medium coverage','Dewy'],34,false,false,
 'A weightless second-skin cushion with a lit finish.',
 'Buildable medium coverage with peptides and ginseng extract to smooth and blur while nourishing.',
 ARRAY['Ginseng','Peptides','Hyaluronic Acid','SPF 40'],
 ARRAY['Poreless finish','SPF protection','Skincare-infused'],
 'Press puff into cushion. Pat onto skin starting from centre outward.',6),
('silk-hair','Silk Bloom Hair Oil','Anua','Hair Care',32,NULL,4.7,402,ARRAY['Non-greasy'],58,true,false,
 'A weightless finishing oil for glass-strand shine.',
 'Camellia and argan oils fused with rice ceramides to smooth frizz, mend split ends, and add a satin glow.',
 ARRAY['Camellia Oil','Argan Oil','Rice Ceramides','Vitamin E'],
 ARRAY['Tames frizz','Adds shine','Heat protection'],
 'Warm 2–3 drops between palms and glide through mid-lengths and ends.',7),
('rice-toner','Rice Water Refining Toner','Beauty of Joseon','Skincare',18,24,4.9,3421,ARRAY['Brightening','Barrier'],300,false,true,
 'Fermented rice toner for the softest, brightest skin.',
 '68% fermented rice water and niacinamide gently brighten and even skin tone while restoring elasticity.',
 ARRAY['Fermented Rice Water 68%','Niacinamide 2%','Alpha-Arbutin'],
 ARRAY['Brightening','Softens texture','Prepares skin for essence'],
 'Soak a cotton pad and sweep across cleansed skin, or press in with palms.',8);
